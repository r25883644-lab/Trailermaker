package com.trailer.maker;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;

public class MainActivity extends Activity {
  WebView w;
  ValueCallback<Uri[]> cb;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    w = new WebView(this);
    setContentView(w);
    final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    w.setWebViewClient(new WebViewClient() {
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
        return loader.shouldInterceptRequest(r.getUrl());
      }
    });
    w.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> c, FileChooserParams p) {
        if (cb != null) cb.onReceiveValue(null);
        cb = c;
        try { startActivityForResult(p.createIntent(), 1); }
        catch (Exception e) { cb = null; return false; }
        return true;
      }
    });
    w.addJavascriptInterface(new Object() {
      @JavascriptInterface public void save(String b64, String name) {
        try {
          byte[] d = Base64.decode(b64, 0);
          ContentValues cv = new ContentValues();
          cv.put(MediaStore.Video.Media.DISPLAY_NAME, name);
          cv.put(MediaStore.Video.Media.MIME_TYPE, name.endsWith("mp4") ? "video/mp4" : "video/webm");
          cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/TrailerMaker");
          Uri u = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
          OutputStream o = getContentResolver().openOutputStream(u);
          o.write(d); o.close();
          toast("Saved to Movies/TrailerMaker");
        } catch (Exception e) { toast("Save failed"); }
      }
    }, "AndroidSave");
    w.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }

  void toast(final String t) { runOnUiThread(() -> Toast.makeText(this, t, Toast.LENGTH_LONG).show()); }

  @Override protected void onActivityResult(int req, int res, Intent data) {
    if (req == 1 && cb != null) {
      cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
      cb = null;
    }
  }

  @Override public void onBackPressed() { if (w.canGoBack()) w.goBack(); else super.onBackPressed(); }
}
